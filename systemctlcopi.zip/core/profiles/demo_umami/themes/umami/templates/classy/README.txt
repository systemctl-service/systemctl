WHAT IS THIS DIRECTORY FOR?
--------------------------------
This directory is for templates previously inherited from the Classy theme.

WHY ARE CLASSY TEMPLATES BEING COPIED HERE?
-------------------------------------------
Classy will be deprecated during the Drupal 9 lifecycle. To prepare for Classy's
removal, templates that would otherwise be inherited from Classy are copied
here.

Templates that differ from the Classy versions should not be placed in this
directory or any subdirectory.
